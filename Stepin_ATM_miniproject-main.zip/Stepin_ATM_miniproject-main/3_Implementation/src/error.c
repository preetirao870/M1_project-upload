/**
 * @file error.c
 * @author Bhavya Thotakura
 * @brief 
 * @version 0.1
 * @date 2021-09-06
 * 
 * @copyright Copyright (c) 2021
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include"atm.h"

 

   int errorMessage() 
{
    printf("+++!!!You selected invalid number!!!+++\n");
    return 9;
}